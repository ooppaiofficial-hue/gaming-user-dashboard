<?php
/**
 * Verification CPT management.
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'GUD_Verification_CPT' ) ) :

class GUD_Verification_CPT {

	/**
	 * Singleton instance.
	 *
	 * @var GUD_Verification_CPT|null
	 */
	protected static $instance = null;

	/**
	 * Get singleton.
	 *
	 * @return GUD_Verification_CPT
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		add_action( 'init', array( $this, 'register_post_type' ) );
		add_action( 'add_meta_boxes', array( $this, 'register_metaboxes' ) );
		add_action( 'save_post_gud_verification', array( $this, 'save_review_status' ) );
		add_filter( 'manage_gud_verification_posts_columns', array( $this, 'register_columns' ) );
		add_action( 'manage_gud_verification_posts_custom_column', array( $this, 'render_columns' ), 10, 2 );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );
		add_action( 'before_delete_post', array( $this, 'handle_submission_delete' ) );
		add_action( 'wp_trash_post', array( $this, 'handle_submission_delete' ) );
		add_action( 'transition_post_status', array( $this, 'sync_status_from_post_status' ), 10, 3 );
	}

	/**
	 * Register verification CPT.
	 *
	 * @return void
	 */
	public function register_post_type() {
		register_post_type(
			'gud_verification',
			array(
				'labels'       => array(
					'name'          => __( 'فرم احراز هویت', 'gaming-user-dashboard' ),
					'singular_name' => __( 'فرم احراز هویت', 'gaming-user-dashboard' ),
					'add_new_item'  => __( 'فرم احراز هویت جدید', 'gaming-user-dashboard' ),
					'edit_item'     => __( 'نمایش فرم احراز هویت', 'gaming-user-dashboard' ),
				),
				'public'       => false,
				'show_ui'      => true,
				'menu_icon'    => 'dashicons-shield-alt',
				'menu_position'=> 26,
				'supports'     => array( 'title' ),
				'show_in_menu' => true,
			)
		);
	}

	/**
	 * Create a verification submission post.
	 *
	 * @param array<string,mixed> $data Submission data.
	 * @return int
	 */
	public function create_submission_post( $data ) {
		$user_id = isset( $data['user_id'] ) ? absint( $data['user_id'] ) : 0;
		if ( $user_id <= 0 ) {
			return 0;
		}

		$user      = get_user_by( 'id', $user_id );
		$user_name = $user ? $user->display_name : __( 'کاربر ناشناس', 'gaming-user-dashboard' );
		$post_id   = wp_insert_post(
			array(
				'post_type'   => 'gud_verification',
				'post_status' => 'publish',
				'post_title'  => sprintf( __( 'درخواست احراز هویت - %s', 'gaming-user-dashboard' ), $user_name ),
			)
		);

		if ( is_wp_error( $post_id ) || empty( $post_id ) ) {
			return 0;
		}

		update_post_meta( $post_id, '_gud_verification_user_id', $user_id );
		update_post_meta( $post_id, '_gud_verification_full_name', isset( $data['full_name'] ) ? sanitize_text_field( $data['full_name'] ) : '' );
		update_post_meta( $post_id, '_gud_verification_mobile', isset( $data['mobile'] ) ? sanitize_text_field( $data['mobile'] ) : '' );
		update_post_meta( $post_id, '_gud_verification_id_cards', isset( $data['id_cards'] ) ? array_map( 'absint', (array) $data['id_cards'] ) : array() );
		update_post_meta( $post_id, '_gud_verification_pledge', isset( $data['pledge_id'] ) ? absint( $data['pledge_id'] ) : 0 );
		update_post_meta( $post_id, '_gud_verification_review_status', 'pending' );
		update_post_meta( $post_id, '_gud_verification_rejection_reason', '' );

		return absint( $post_id );
	}

	/**
	 * Add metaboxes.
	 *
	 * @return void
	 */
	public function register_metaboxes() {
		add_meta_box(
			'gud-verification-details',
			__( 'جزئیات فرم احراز هویت', 'gaming-user-dashboard' ),
			array( $this, 'render_details_metabox' ),
			'gud_verification',
			'normal',
			'high'
		);
	}

	/**
	 * Render detail metabox.
	 *
	 * @param WP_Post $post Post object.
	 * @return void
	 */
	public function render_details_metabox( $post ) {
		wp_nonce_field( 'gud_verification_review_status', 'gud_verification_review_status_nonce' );

		$user_id      = absint( get_post_meta( $post->ID, '_gud_verification_user_id', true ) );
		$full_name    = (string) get_post_meta( $post->ID, '_gud_verification_full_name', true );
		$mobile       = (string) get_post_meta( $post->ID, '_gud_verification_mobile', true );
		$id_cards     = (array) get_post_meta( $post->ID, '_gud_verification_id_cards', true );
		$pledge_id    = absint( get_post_meta( $post->ID, '_gud_verification_pledge', true ) );
		$review_state = (string) get_post_meta( $post->ID, '_gud_verification_review_status', true );
		if ( empty( $review_state ) ) {
			$review_state = 'pending';
		}

		$user = get_user_by( 'id', $user_id );
		?>
		<div class="gud-admin-card">
			<div class="gud-admin-grid">
				<div><strong><?php echo esc_html__( 'کاربر', 'gaming-user-dashboard' ); ?>:</strong> <?php echo esc_html( $user ? $user->display_name : '-' ); ?></div>
				<div><strong><?php echo esc_html__( 'شناسه کاربر', 'gaming-user-dashboard' ); ?>:</strong> <?php echo esc_html( (string) $user_id ); ?></div>
				<div><strong><?php echo esc_html__( 'نام و نام خانوادگی', 'gaming-user-dashboard' ); ?>:</strong> <?php echo esc_html( $full_name ); ?></div>
				<div><strong><?php echo esc_html__( 'شماره موبایل', 'gaming-user-dashboard' ); ?>:</strong> <?php echo esc_html( $mobile ); ?></div>
			</div>

			<div class="gud-admin-status">
				<label for="gud_verification_review_status"><strong><?php echo esc_html__( 'وضعیت بررسی', 'gaming-user-dashboard' ); ?>:</strong></label>
				<select id="gud_verification_review_status" name="gud_verification_review_status">
					<option value="pending" <?php selected( $review_state, 'pending' ); ?>><?php echo esc_html__( 'در حال بررسی', 'gaming-user-dashboard' ); ?></option>
					<option value="rejected" <?php selected( $review_state, 'rejected' ); ?>><?php echo esc_html__( 'رد شده', 'gaming-user-dashboard' ); ?></option>
					<option value="approved" <?php selected( $review_state, 'approved' ); ?>><?php echo esc_html__( 'تایید شده', 'gaming-user-dashboard' ); ?></option>
				</select>
			</div>

			<div class="gud-admin-status gud-admin-reason">
				<label for="gud_verification_rejection_reason"><strong><?php echo esc_html__( 'دلیل رد شدن', 'gaming-user-dashboard' ); ?>:</strong></label>
				<textarea id="gud_verification_rejection_reason" name="gud_verification_rejection_reason" rows="4" placeholder="<?php echo esc_attr__( 'در صورت رد شدن، دلیل را وارد کنید...', 'gaming-user-dashboard' ); ?>"><?php echo esc_textarea( (string) get_post_meta( $post->ID, '_gud_verification_rejection_reason', true ) ); ?></textarea>
			</div>

			<div class="gud-admin-images">
				<h4><?php echo esc_html__( 'تصاویر کارت ملی (پشت و رو)', 'gaming-user-dashboard' ); ?></h4>
				<div class="gud-admin-image-list">
					<?php foreach ( $id_cards as $id_card_id ) : ?>
						<div class="gud-admin-image-item">
							<?php echo wp_kses_post( wp_get_attachment_image( absint( $id_card_id ), 'medium' ) ); ?>
						</div>
					<?php endforeach; ?>
				</div>
			</div>

			<div class="gud-admin-images">
				<h4><?php echo esc_html__( 'تصویر تعهدنامه', 'gaming-user-dashboard' ); ?></h4>
				<div class="gud-admin-image-item">
					<?php echo wp_kses_post( wp_get_attachment_image( $pledge_id, 'medium' ) ); ?>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Save review status.
	 *
	 * @param int $post_id Post ID.
	 * @return void
	 */
	public function save_review_status( $post_id ) {
		if ( ! isset( $_POST['gud_verification_review_status_nonce'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return;
		}

		$nonce = wp_unslash( $_POST['gud_verification_review_status_nonce'] ); // phpcs:ignore WordPress.Security.NonceVerification
		if ( ! wp_verify_nonce( $nonce, 'gud_verification_review_status' ) ) {
			return;
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		$status = isset( $_POST['gud_verification_review_status'] ) ? sanitize_key( wp_unslash( $_POST['gud_verification_review_status'] ) ) : 'pending'; // phpcs:ignore WordPress.Security.NonceVerification
		$allowed_statuses = array( 'pending', 'rejected', 'approved' );
		if ( ! in_array( $status, $allowed_statuses, true ) ) {
			$status = 'pending';
		}

		$reason = isset( $_POST['gud_verification_rejection_reason'] ) ? sanitize_textarea_field( wp_unslash( $_POST['gud_verification_rejection_reason'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		if ( 'rejected' !== $status ) {
			$reason = '';
		}

		update_post_meta( $post_id, '_gud_verification_review_status', $status );
		update_post_meta( $post_id, '_gud_verification_rejection_reason', $reason );

		$user_id = absint( get_post_meta( $post_id, '_gud_verification_user_id', true ) );
		if ( $user_id > 0 ) {
			update_user_meta( $user_id, 'gud_verification_status', $status );
			update_user_meta( $user_id, 'gud_verification_rejection_reason', $reason );
		}
	}


	/**
	 * Reset user verification meta when an admin removes a submission.
	 *
	 * @param int $post_id Post ID.
	 * @return void
	 */
	public function handle_submission_delete( $post_id ) {
		$post = get_post( $post_id );
		if ( ! $post || 'gud_verification' !== $post->post_type ) {
			return;
		}

		$user_id = absint( get_post_meta( $post_id, '_gud_verification_user_id', true ) );
		if ( $user_id <= 0 ) {
			return;
		}

		delete_user_meta( $user_id, 'gud_verification_full_name' );
		delete_user_meta( $user_id, 'gud_verification_mobile' );
		delete_user_meta( $user_id, 'gud_verification_id_cards' );
		delete_user_meta( $user_id, 'gud_verification_pledge' );
		delete_user_meta( $user_id, 'gud_verification_rules_accepted' );
		delete_user_meta( $user_id, 'gud_verification_rejection_reason' );
		delete_user_meta( $user_id, 'gud_verification_submitted_at' );
		delete_user_meta( $user_id, 'gud_verification_post_id' );
		update_user_meta( $user_id, 'gud_verification_status', 'none' );
	}

	/**
	 * Keep user verification status synced with post status transitions.
	 *
	 * Draft is treated as rejected per business requirement.
	 *
	 * @param string  $new_status New post status.
	 * @param string  $old_status Old post status.
	 * @param WP_Post $post Post object.
	 * @return void
	 */
	public function sync_status_from_post_status( $new_status, $old_status, $post ) {
		if ( ! $post instanceof WP_Post || 'gud_verification' !== $post->post_type ) {
			return;
		}

		if ( $new_status === $old_status ) {
			return;
		}

		$user_id = absint( get_post_meta( $post->ID, '_gud_verification_user_id', true ) );
		if ( $user_id <= 0 ) {
			return;
		}

		if ( 'draft' === $new_status ) {
			update_post_meta( $post->ID, '_gud_verification_review_status', 'rejected' );
			update_user_meta( $user_id, 'gud_verification_status', 'rejected' );

			$reason = (string) get_post_meta( $post->ID, '_gud_verification_rejection_reason', true );
			update_user_meta( $user_id, 'gud_verification_rejection_reason', $reason );
		}
	}

	/**
	 * Register columns.
	 *
	 * @param array $columns Columns.
	 * @return array
	 */
	public function register_columns( $columns ) {
		$columns['gud_user']   = __( 'کاربر', 'gaming-user-dashboard' );
		$columns['gud_mobile'] = __( 'شماره موبایل', 'gaming-user-dashboard' );
		$columns['gud_status'] = __( 'وضعیت', 'gaming-user-dashboard' );
		return $columns;
	}

	/**
	 * Render custom columns.
	 *
	 * @param string $column_name Column name.
	 * @param int    $post_id Post ID.
	 * @return void
	 */
	public function render_columns( $column_name, $post_id ) {
		if ( 'gud_user' === $column_name ) {
			$user_id = absint( get_post_meta( $post_id, '_gud_verification_user_id', true ) );
			$user    = get_user_by( 'id', $user_id );
			echo esc_html( $user ? $user->display_name : '-' );
		}

		if ( 'gud_mobile' === $column_name ) {
			echo esc_html( (string) get_post_meta( $post_id, '_gud_verification_mobile', true ) );
		}

		if ( 'gud_status' === $column_name ) {
			$status = (string) get_post_meta( $post_id, '_gud_verification_review_status', true );
			$map = array(
				'pending'  => __( 'در حال بررسی', 'gaming-user-dashboard' ),
				'rejected' => __( 'رد شده', 'gaming-user-dashboard' ),
				'approved' => __( 'تایید شده', 'gaming-user-dashboard' ),
			);
			echo esc_html( isset( $map[ $status ] ) ? $map[ $status ] : $map['pending'] );
		}
	}

	/**
	 * Enqueue admin CSS.
	 *
	 * @param string $hook_suffix Hook suffix.
	 * @return void
	 */
	public function enqueue_admin_assets( $hook_suffix ) {
		$screen = get_current_screen();
		if ( empty( $screen ) || 'gud_verification' !== $screen->post_type ) {
			return;
		}

		wp_enqueue_style(
			'gud-admin-style',
			plugins_url( '../assets/css/gud-admin.css', __FILE__ ),
			array(),
			'1.0.0'
		);
	}
}

endif;
